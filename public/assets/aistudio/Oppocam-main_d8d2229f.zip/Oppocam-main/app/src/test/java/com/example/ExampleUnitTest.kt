package com.example

import com.example.camera.model.CameraResolution
import com.example.camera.model.LensInfo
import com.example.camera.model.LensType
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleUnitTest {
    @Test
    fun testMainActivityLaunch() {
        val controller = Robolectric.buildActivity(MainActivity::class.java)
        controller.setup()
        assertNotNull(controller.get())
    }

    @Test
    fun testMainActivityLaunchWithPermissionsGranted() {
        val app = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.app.Application>()
        val shadowApp = org.robolectric.Shadows.shadowOf(app)
        shadowApp.grantPermissions(android.Manifest.permission.CAMERA, android.Manifest.permission.RECORD_AUDIO)

        val controller = Robolectric.buildActivity(MainActivity::class.java)
        controller.setup()
        assertNotNull(controller.get())
    }

    @Test
    fun testCameraResolutionCalculations() {
        val res43 = CameraResolution(4000, 3000)
        assertEquals(12.0f, res43.megapixels, 0.01f)
        assertEquals("4:3", res43.aspectRatioLabel)

        val res169 = CameraResolution(3840, 2160)
        assertEquals(8.29f, res169.megapixels, 0.02f)
        assertEquals("16:9", res169.aspectRatioLabel)

        val res209 = CameraResolution(2400, 1080)
        assertEquals("20:9", res209.aspectRatioLabel)
    }

    @Test
    fun testLensInfoTypes() {
        val ultraWide = LensInfo(
            cameraId = "2",
            facing = android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK,
            lensType = LensType.ULTRAWIDE,
            displayName = "0.5x Ultra Wide",
            focalLengthMm = 1.94f,
            maxAperture = 2.2f,
            isPhysical = true,
            isHiddenAux = true,
            fovDegrees = 118f
        )
        assertEquals("0.5x", ultraWide.lensType.shortLabel)
        assertEquals("Ultra Wide", ultraWide.lensType.fullLabel)
        assertTrue(ultraWide.isPhysical)
        assertTrue(ultraWide.isHiddenAux)
    }

    @Test
    fun testMirrorSelfiePreferenceDefault() {
        val prefs = com.example.camera.data.CameraPreferences(
            androidx.test.core.app.ApplicationProvider.getApplicationContext()
        )
        // Default is true for "Save selfie as previewed (without flipping)"
        assertTrue(prefs.saveSelfieAsPreviewed)
        prefs.saveSelfieAsPreviewed = false
        assertFalse(prefs.saveSelfieAsPreviewed)
        prefs.saveSelfieAsPreviewed = true
        assertTrue(prefs.saveSelfieAsPreviewed)
    }

    @Test
    fun testRawVideoModeCompletelyPurged() {
        val modes = com.example.camera.model.CameraMode.entries.map { it.name }
        assertFalse("RAW_VIDEO should not exist in CameraMode", modes.contains("RAW_VIDEO"))
    }

    @Test
    fun testCinemaColorProfilesExactSet() {
        val expectedProfiles = setOf("PROCESSED_JPEG", "NATIVE", "S_LOG", "N_LOG", "HLG10", "HLG_2", "APPLE_LOG_2", "D_LOG_2", "SAMSUNG_APV_LOG")
        val actualProfiles = com.example.camera.model.CinemaColorProfile.entries.map { it.name }.toSet()
        assertEquals(expectedProfiles, actualProfiles)
        assertFalse("FLAT_LOG must be completely removed", actualProfiles.contains("FLAT_LOG"))
        assertFalse("HDR_LOG must be completely removed", actualProfiles.contains("HDR_LOG"))
        assertFalse("REC_2020 must be completely removed as a profile", actualProfiles.contains("REC_2020"))
        assertTrue("S_LOG must exist", actualProfiles.contains("S_LOG"))
        assertTrue("N_LOG must exist", actualProfiles.contains("N_LOG"))
        assertTrue("HLG10 must exist", actualProfiles.contains("HLG10"))
        assertTrue("HLG_2 must exist", actualProfiles.contains("HLG_2"))
        assertTrue("D_LOG_2 must exist", actualProfiles.contains("D_LOG_2"))
    }

    @Test
    fun testDLog2TransferFunctionAndBalance() {
        val engine = com.example.camera.engine.CinemaEngine(androidx.test.core.app.ApplicationProvider.getApplicationContext())
        
        // 1. Shadow black floor preservation (pedestal around 0.08 to prevent shadow clipping)
        val blackFloor = engine.evaluateLogTransferFunction(com.example.camera.model.CinemaColorProfile.D_LOG_2, 0.0f)
        assertEquals(0.080f, blackFloor, 0.005f)

        // 2. Middle-gray 18% reference maps to balanced log exposure (~0.39) preventing underexposure
        val midGray = engine.evaluateLogTransferFunction(com.example.camera.model.CinemaColorProfile.D_LOG_2, 0.18f)
        assertTrue("D-Log 2 middle gray should map to ~0.39 for balanced exposure, was $midGray", midGray in 0.38f..0.41f)

        // 3. Highlight retention: 100% white retains full scale up to 1.0 without clipping
        val peakVal = engine.evaluateLogTransferFunction(com.example.camera.model.CinemaColorProfile.D_LOG_2, 1.0f)
        assertEquals(1.0f, peakVal, 0.001f)

        // 4. Smooth monotonic curvature across dynamic range
        val shadowVal = engine.evaluateLogTransferFunction(com.example.camera.model.CinemaColorProfile.D_LOG_2, 0.05f)
        val midVal = engine.evaluateLogTransferFunction(com.example.camera.model.CinemaColorProfile.D_LOG_2, 0.50f)
        val highVal = engine.evaluateLogTransferFunction(com.example.camera.model.CinemaColorProfile.D_LOG_2, 0.85f)
        assertTrue(blackFloor < shadowVal)
        assertTrue(shadowVal < midGray)
        assertTrue(midGray < midVal)
        assertTrue(midVal < highVal)
        assertTrue(highVal < peakVal)
    }

    @Test
    fun testHlg10AribStdB67OetfTransferFunction() {
        // Test ARIB STD-B67 mathematical boundary conditions:
        // 1. Black anchor at zero: E=0 -> E'=0
        val zeroVal = com.example.camera.engine.Hlg10AutoExposureEngine.evaluateAribOetf(0.0f)
        assertEquals(0.0f, zeroVal, 0.0001f)

        // 2. Split point at 1/12 (approx 0.083333f):
        // sqrt(3 * 1/12) = sqrt(1/4) = 0.5
        val splitVal = com.example.camera.engine.Hlg10AutoExposureEngine.evaluateAribOetf(1.0f / 12.0f)
        assertEquals(0.5f, splitVal, 0.001f)

        // 3. Peak 1.0 (100% video diffuse white level): E=1.0 -> E'=1.0
        val peakVal = com.example.camera.engine.Hlg10AutoExposureEngine.evaluateAribOetf(1.0f)
        assertEquals(1.0f, peakVal, 0.001f)

        // 4. Middle gray 18% reference: E=0.18 -> E' in [0.65, 0.70] (log shoulder)
        val midGray = com.example.camera.engine.Hlg10AutoExposureEngine.evaluateAribOetf(0.18f)
        assertTrue("Middle gray should be in logarithmic range, got $midGray", midGray in 0.60f..0.75f)
    }

    @Test
    fun testHlg10TonemapCurveNonFlatInkyBlacks() {
        val engine = com.example.camera.engine.Hlg10AutoExposureEngine()
        val curve = engine.getTonemapCurve()
        assertNotNull(curve)

        // Black level point at x=0 must be inky black (y=0) to prevent flat/washed-out appearance
        val pt0 = curve.getPoint(android.hardware.camera2.params.TonemapCurve.CHANNEL_GREEN, 0)
        assertEquals(0.0f, pt0.x, 0.001f)
        assertEquals(0.0f, pt0.y, 0.005f)

        // Peak point at x=1.0 must reach 1.0
        val lastIdx = curve.getPointCount(android.hardware.camera2.params.TonemapCurve.CHANNEL_GREEN) - 1
        val ptEnd = curve.getPoint(android.hardware.camera2.params.TonemapCurve.CHANNEL_GREEN, lastIdx)
        assertEquals(1.0f, ptEnd.x, 0.001f)
        assertEquals(1.0f, ptEnd.y, 0.01f)
    }

    @Test
    fun testNativeNaturalVideoEngineColorProcessing() {
        val engine = com.example.camera.engine.NativeNaturalVideoEngine()
        // Simulate normal outdoor landscape EV100
        engine.processSceneIllumination(ev100 = 14.5f, hasFace = false)
        val params = engine.currentParams.value
        // Verify outdoor sky protection parameters
        assertTrue(params.isOutdoorSkyPresent)
        assertTrue(params.highlightCompression > 0.3f)

        val curve = engine.getTonemapCurve()
        assertNotNull(curve)
        // Pedestal (x=0) should be pinned to 0.0 (inky blacks, no wash out)
        val pt0 = curve.getPoint(android.hardware.camera2.params.TonemapCurve.CHANNEL_GREEN, 0)
        assertEquals(0.0f, pt0.y, 0.001f)
    }

    @Test
    fun testRemovedModesPurgedFromCameraMode() {
        val modes = com.example.camera.model.CameraMode.entries.map { it.name }
        assertFalse("DOLLY_ZOOM should not exist in CameraMode", modes.contains("DOLLY_ZOOM"))
        assertFalse("HUMAN_VISION should not exist in CameraMode", modes.contains("HUMAN_VISION"))
    }

    @Test
    fun testDualVideoModeRemoved() {
        val modes = com.example.camera.model.CameraMode.entries.map { it.name }
        assertFalse("DUAL_VIDEO should not exist in CameraMode", modes.contains("DUAL_VIDEO"))
    }

    @Test
    fun testCinemaCodecsAndFileExtensions() {
        val vp9Codec = com.example.camera.model.CinemaCodec.VP9
        val proResCodec = com.example.camera.model.CinemaCodec.PRORES
        val h264Codec = com.example.camera.model.CinemaCodec.H264
        val h265Codec = com.example.camera.model.CinemaCodec.H265

        // VP9 uses webm container
        val isVp9Software = true
        val vp9Extension = if (isVp9Software && vp9Codec == com.example.camera.model.CinemaCodec.VP9) "webm" else "mp4"
        assertEquals("webm", vp9Extension)

        // ProRes and H264/H265 use mp4 container
        val proResExtension = if (isVp9Software && proResCodec == com.example.camera.model.CinemaCodec.VP9) "webm" else "mp4"
        assertEquals("mp4", proResExtension)

        val h264Extension = if (false && h264Codec == com.example.camera.model.CinemaCodec.VP9) "webm" else "mp4"
        assertEquals("mp4", h264Extension)
    }

    @Test
    fun testCinemaTempFileCreationAndCleanup() {
        val context = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()
        val cacheDir = context.cacheDir.apply { mkdirs() }
        assertTrue(cacheDir.exists())

        val tempFile = java.io.File(cacheDir, "cinema_temp_${System.currentTimeMillis()}.mp4")
        if (tempFile.exists()) tempFile.delete()
        tempFile.createNewFile()
        assertTrue(tempFile.exists())
        assertEquals(0L, tempFile.length())

        // Simulate writing recorded bytes
        val testData = "test_video_data".toByteArray()
        tempFile.writeBytes(testData)
        assertEquals(testData.size.toLong(), tempFile.length())

        // Cleanup
        tempFile.delete()
        assertFalse(tempFile.exists())
    }

    @Test
    fun testMotorolaInstantSwitchPreferencesIndependence() {
        val prefs = com.example.camera.data.CameraPreferences(
            androidx.test.core.app.ApplicationProvider.getApplicationContext()
        )

        // Test default values
        assertFalse(prefs.isShowUltraWidePreview)
        assertTrue(prefs.isKeepFrontCameraReady)
        assertFalse(prefs.isShowFrontCameraPreview)

        // Test independent toggling for Ultra-Wide Preview
        prefs.isShowUltraWidePreview = false
        assertFalse(prefs.isShowUltraWidePreview)

        prefs.isShowUltraWidePreview = true
        assertTrue(prefs.isShowUltraWidePreview)

        // Test independent toggling for Front Camera
        // Front Ready ON + Preview OFF
        prefs.isKeepFrontCameraReady = true
        prefs.isShowFrontCameraPreview = false
        assertTrue(prefs.isKeepFrontCameraReady)
        assertFalse(prefs.isShowFrontCameraPreview)

        // Front Ready ON + Preview ON
        prefs.isShowFrontCameraPreview = true
        assertTrue(prefs.isKeepFrontCameraReady)
        assertTrue(prefs.isShowFrontCameraPreview)

        // Front Ready OFF
        prefs.isKeepFrontCameraReady = false
        assertFalse(prefs.isKeepFrontCameraReady)
    }
}
